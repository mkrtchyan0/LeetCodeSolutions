﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Dal.Entities
{
    public class Booked
    {
        public int Id { get; set; }
        public int UserIdentity { get; set; }
        public int Total { get; set; }
    }
}
