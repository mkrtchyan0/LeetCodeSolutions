﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Dal.Tools
{
    public class  CarType
    {
        List<string> types = new List<string>();

        public CarType()
        {
            types.Add("Jeep");
            types.Add("Sedan");
            types.Add("Fur");
        }
        public int GetAmount(string car)
        {
            if (car == types[0])
            {
                return 200;
            }
            else if (car == types[1])
            {
                return 300;
            }
            else if(car == types[3])
            {
                return 500;
            }
            return 0;
        }
    }
}
