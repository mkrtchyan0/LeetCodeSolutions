﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Dal.Tools
{
    public class FromTo
    {
        public Dictionary<string, string> fromTo = new Dictionary<string, string>();
        public List<string> Cities = new List<string>();
        
        public FromTo()
        {
            fromTo.Add("Gyumri","Yerevan");
            fromTo.Add("Mexri","Yerevan");

            Cities.Add("");
            Cities.Add("Gyumri");
            Cities.Add("Mexri");
        }
        public int GetAmount(string from, string to)
        {
            if (fromTo.ContainsKey(from) && fromTo[from] == to)
            {
                return 200 * Cities.IndexOf(from);
            }
            else
            {
                return 500; // Another
            }
        }
    }
}
