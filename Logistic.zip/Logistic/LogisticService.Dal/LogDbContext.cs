﻿using LogisticService.Dal.Entities;
using Microsoft.EntityFrameworkCore;

namespace LogisticService.Dal
{
    public class LogDbContext : DbContext
    {
        public LogDbContext(DbContextOptions options) : base(options)
        {
            
        }
        public DbSet<Booked> Books { get; set; }
    }
}
