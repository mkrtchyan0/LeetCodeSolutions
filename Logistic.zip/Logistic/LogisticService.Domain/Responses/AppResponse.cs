﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Domain.Responses
{
    public class AppResponse
    {
        public int StatusCode { get; set; }
        public bool Succeeded { get; set; }
        public string Message { get; set; }

        public static AppResponse Ok(string message)
        {
            return new AppResponse
            {
                StatusCode = 200,
                Succeeded = true,
                Message = message
            };
        }
        public static AppResponse Fail(string message)
        {
            return new AppResponse
            {
                StatusCode = 400,
                Succeeded = false,
                Message = message
            };
        }
    }
}
