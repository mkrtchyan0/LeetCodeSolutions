﻿using FluentValidation;
using LogisticService.Dal.Tools;
using LogisticService.Domain.Responses;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Application.Commands
{
    public class OrderRaceCommand : IRequest<AppResponse>
    {
        public string CarType { get; set; }
        public bool IsOperable { get; set; }
        public bool IsContainer { get; set; }
        public string From { get; set; }
        public string To { get; set; }
        public int IdentityNumber { get; set; }

    }
    public class OrderRaceValidator : AbstractValidator<OrderRaceCommand>
    {
        public OrderRaceValidator()
        {
            RuleFor(x => x.CarType).NotEmpty().WithMessage("CarType is required!!");
            RuleFor(x => x.IsOperable).NotEmpty().WithMessage("Operable or not?!");
            RuleFor(x => x.IsContainer).NotEmpty().WithMessage("With or Without Container?!");
            RuleFor(x => x.From).NotEmpty().WithMessage("Choose from where bring the car!");
            RuleFor(x => x.To).NotEmpty().WithMessage("Choose where bring the car");
            RuleFor(x => x.IdentityNumber).NotEmpty().WithMessage("Write user identity!");
        }
    }
}
