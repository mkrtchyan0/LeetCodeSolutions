﻿using LogisticService.Dal;
using LogisticService.Dal.Entities;
using LogisticService.Dal.Tools;
using LogisticService.Domain.Responses;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LogisticService.Application.Commands.Handlers
{
    public class OrderRaceCommandHandler(LogDbContext context) : IRequestHandler<OrderRaceCommand, AppResponse>
    {
        public async Task<AppResponse> Handle(OrderRaceCommand request, CancellationToken cancellationToken)
        {
            try
            {
                int total = 0;
                CarType carType = new CarType();
                FromTo fromTo = new FromTo();

                if (request.IsOperable == true)
                {
                    total += 200;
                }
                if (request.IsContainer == true)
                {
                    total += 300;
                }
                int carAmount = carType.GetAmount(request.CarType);
                int fromToAmount = fromTo.GetAmount(request.From, request.To);

                total += fromToAmount += carAmount;

                var book = new Booked
                {
                    Total = total,
                    UserIdentity = request.IdentityNumber
                };
                context.Books.Add(book);
                context.SaveChanges();

                return AppResponse.Ok("Your amount is " + total);
            }
            catch (Exception)
            {
                return AppResponse.Fail("Something goes wrong.");
            }         
        }
    }
}
