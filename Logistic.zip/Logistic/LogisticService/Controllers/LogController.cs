﻿using LogisticService.Application.Commands;
using LogisticService.Domain.Responses;
using MediatR;
using Microsoft.AspNetCore.Mvc;

namespace LogisticService.Controllers
{
    public class LogController(IMediator mediator) : ControllerBase
    {
        [HttpPost]
        [Route("api/buy")]
        public async Task<AppResponse> BuyARace(OrderRaceCommand command, CancellationToken token)
        {
            return await mediator.Send(command, token);
        }
    }
}
